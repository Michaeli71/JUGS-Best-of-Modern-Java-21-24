package java21_final.pattern_matching;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class Example
{
    public static void main(String[] args) {
        handleTriangleAndRectangle(new Triangle(7271));
        handleTriangleAndRectangle(new Triangle(71));
        handleTriangleAndRectangle(new Rectangle(0, 0, 20, 7));
        handleTriangleAndRectangle(new Rectangle(0, 0, 200, 7));
    }

    static void handleTriangleAndRectangle(final Shape shape)
    {
        switch (shape)
        {
            case Triangle triangle when triangle.area() > 100 ->
                    System.out.println("big triangle");
            case Triangle triangle when triangle.area() > 50 &&
                    triangle.area() <= 100  ->
                    System.out.println("medium triangle");
            case Rectangle rect when rect.width() > 100 || rect.height() > 100 ->
                    System.out.println("big rect");
            default -> System.out.println("Something else: " + shape);
        }
    }

}
