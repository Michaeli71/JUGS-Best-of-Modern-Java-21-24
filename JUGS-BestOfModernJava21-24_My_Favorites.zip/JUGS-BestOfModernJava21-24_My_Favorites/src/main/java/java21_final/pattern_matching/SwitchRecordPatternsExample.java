package java21_final.pattern_matching;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class SwitchRecordPatternsExample
{
   public static void main(String[] args)
    {
        recordPatternsAndMatching(new Pos3D(7,2, 71));
        recordPatternsAndMatching(new Pos3D(7,2, 0));
        recordPatternsAndMatching(RgbColor.GREEN);
        recordPatternsAndMatching("MICHAEL");
    }

    record Pos3D(int x, int y, int z) {
    }

    enum RgbColor {RED, GREEN, BLUE}

    static void recordPatternsAndMatching(Object obj)
    {
        switch (obj)
        {
            case RgbColor color when color == RgbColor.RED ->
                    System.out.println("RED WARNING");
            case RgbColor color -> System.out.println("Enum: " + color);
            case Pos3D pos when pos.z() == 0 ->
                    System.out.println("Record: " + pos);
            case Pos3D(int x, int y, int z) when y > 0 ->
                    System.out.println("Record decomposed: " + x + ", " +
                            y + ", " + z);
            default -> System.out.println("Something else");
        }
    }
}
