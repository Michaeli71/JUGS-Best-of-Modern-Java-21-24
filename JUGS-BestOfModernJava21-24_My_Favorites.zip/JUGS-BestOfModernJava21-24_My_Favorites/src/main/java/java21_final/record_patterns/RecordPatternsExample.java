package java21_final.record_patterns;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RecordPatternsExample
{
    record Point(int x, int y) {}

    static void printCoordinateInfo(Object obj)
    {
        if (obj instanceof Point point)
        {
            int x = point.x();
            int y = point.y();

            System.out.println("x: %d, y: %d, sum: %d".formatted(x, y, x + y));
        }
    }

    static void printCoordinateInfoNew(Object obj)
    {
        if (obj instanceof Point(int x, int y))
        {
            System.out.println("x: %d, y: %d, sum: %d".formatted(x, y, x + y));
        }
    }
    
    public static void main(String[] args)
    {
        printCoordinateInfo(new Point(72, 71));
        printCoordinateInfoNew(new Point(72, 71));
    }
}