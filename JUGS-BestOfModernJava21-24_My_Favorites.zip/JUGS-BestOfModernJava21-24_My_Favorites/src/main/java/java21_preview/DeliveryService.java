package java21_preview;

public class DeliveryService {
    private String type;

    public DeliveryService(String type) {
        this.type = type;
    }
}
