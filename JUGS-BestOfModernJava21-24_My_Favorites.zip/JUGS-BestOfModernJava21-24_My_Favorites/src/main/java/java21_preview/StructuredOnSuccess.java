package java21_preview;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.StructuredTaskScope;

public class StructuredOnSuccess {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        try (var scope = new StructuredTaskScope.ShutdownOnSuccess<DeliveryService>()) {
            var result1 = scope.fork(() -> tryToGetPostService());
            var result2 = scope.fork(() -> tryToGetFallbackService());
            var result3 = scope.fork(() -> tryToGetCheapService());
            var result4 = scope.fork(() -> tryToGetFastDeliveryService());
            scope.join();
            // KEIN throwIfFailed()

            System.out.println("PS " + result1.state() + "/FS " + result2.state() + STR."/CS \{result3.state()}/FDS \{result4.state()}");

            System.out.println("found delivery service: " + scope.result());
        }
    }

    private static DeliveryService tryToGetCheapService() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new DeliveryService("CheapService");
    }

    private static DeliveryService tryToGetFastDeliveryService() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new DeliveryService("FastDeliveryService");
    }

    private static DeliveryService tryToGetFallbackService() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new DeliveryService("FallbackService");
    }

    private static DeliveryService tryToGetPostService() throws InterruptedException {
        sleepRandomlyUpToOneSec();
        return new DeliveryService("PostService");
    }

    private static void sleepRandomlyUpToOneSec() throws InterruptedException {
        Thread.sleep((long) (1000 + 1000 * Math.random()));
    }
}
