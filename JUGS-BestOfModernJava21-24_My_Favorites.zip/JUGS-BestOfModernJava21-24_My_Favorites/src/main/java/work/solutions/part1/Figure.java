package solutions;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023, 2024 by Michael Inden
 */
public sealed interface Figure permits Line, Point, Triangle {
}

