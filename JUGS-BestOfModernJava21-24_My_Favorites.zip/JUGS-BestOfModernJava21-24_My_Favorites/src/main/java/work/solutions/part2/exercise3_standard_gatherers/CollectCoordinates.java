package work.solutions.part2.exercise3_standard_gatherers;

import java.util.List;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class CollectCoordinates {
	record Point3d(int x, int y, int z) {
        // BONUS:
        Point3d(List<Integer> values)
        {
            this(values.get(0), values.get(1), values.get(2));
        }
    }
	
	public static void main(String[] args) {
        
        var coordinates = Stream.of(0, 0, 0, 10, 20, 30, 100, 200, 300, 1000, 2000, 3000).
                gather(java.util.stream.Gatherers.windowFixed(3)).
                map(window -> new Point3d(window.get(0), window.get(1), window.get(2))).
                toList();
        System.out.println("coordinates: " + coordinates);

        var coordinates2 = Stream.of(0, 0, 0, 10, 20, 30, 100, 200, 300, 1000, 2000, 3000).
                gather(java.util.stream.Gatherers.windowFixed(3)).
                map(window -> new Point3d(window)).
                toList();
        System.out.println("coordinates2: " + coordinates2);
    }
}
