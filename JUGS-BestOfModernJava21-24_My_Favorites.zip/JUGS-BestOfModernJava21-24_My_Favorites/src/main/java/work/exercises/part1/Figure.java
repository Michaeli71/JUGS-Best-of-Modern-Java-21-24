package work.exercises.part1;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023, 2024 by Michael Inden
 */
public sealed interface Figure {
}

record Point(int x, int y) implements Figure {
}

record Line(Point start,
            Point end) implements Figure {
}

record Triangle(Point pointA,
                Point pointB,
                Point PointC) implements Figure {
}