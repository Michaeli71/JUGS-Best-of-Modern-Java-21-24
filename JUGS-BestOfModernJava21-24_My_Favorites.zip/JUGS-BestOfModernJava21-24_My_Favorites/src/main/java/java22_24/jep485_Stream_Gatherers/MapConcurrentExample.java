package java22_24.jep485_Stream_Gatherers;

import java.util.stream.Gatherers;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.io.IO.println;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class MapConcurrentExample {
    public static void main(String[] args)
    {
        println(Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).
                gather(Gatherers.mapConcurrent(5, x -> x * x)).
                toList());

        Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).
                parallel().
                map(x -> x * x).
                toList();


        println("parallel 500:");
        var result3 = IntStream.rangeClosed(0, 499).
                boxed().
                parallel().
                map(LookupService::lookup).
                toList();
        println("parallel 500:" + result3);

        println("mapConcurrent 500:");
        var result4 = IntStream.rangeClosed(0, 499).
                boxed().
                gather(Gatherers.mapConcurrent(250,
                        LookupService::lookup)).
                toList();
        println("mapConcurrent 500:" + result4);
        var result5 = IntStream.rangeClosed(0, 499).
                boxed().
                gather(Gatherers.mapConcurrent(500,
                        LookupService::lookup)).
                toList();
        println(result5);

        // Faktor 1000, aber immer noch 1 Sekunde
        var result6 = IntStream.rangeClosed(0, 499999).
                boxed().
                gather(Gatherers.mapConcurrent(500000,
                        LookupService::lookup)).
                toList();
        println(result6);
    }

    static class LookupService
    {
        static int lookup(final int key)
        {
            try
            {
                Thread.sleep(1000);
                return key * key;
            }
            catch (InterruptedException e)
            {
                throw new RuntimeException(e);
            }
        }
    }
}
