package all_time_favorites;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class NPE_Third_Example
{
    public static void main(final String[] args) 
    {
        int width = getWindowManager().getWindow(5).size().width();
        System.out.println("Width: "  + width);
    }
    
    public static WindowManager getWindowManager() 
    {       
        return new WindowManager();
    }
    
    public static class WindowManager
    {
        public Window getWindow(final int i) 
        {
            return null;
        }   
    }
    
    public static record Window(Size size) {}
    public static record Size(int width, int height) {}
}