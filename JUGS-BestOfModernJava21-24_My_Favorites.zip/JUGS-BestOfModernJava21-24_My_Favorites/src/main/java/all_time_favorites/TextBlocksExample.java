package all_time_favorites;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class TextBlocksExample {

    public static void main(String[] args) {

        String multiLineString = """
            THIS IS
            A MULTI
            LINE STRING
            WITH A BACKSLASH \\
            """;
        System.out.println(multiLineString);


        String jsonObj = """
                {
                    "name": "Mike",
                    "birthday": "1971-02-07",
                    "comment": "Text blocks are nice!"
                }
                """;

        System.out.println(jsonObj);

        String text = """
                This is a string splitted in several smaller \
                jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj \
                jjjjjjjjjjjjjjjjjjjjjjjj \
                jjjjjjjjjjjj strings""";

        System.out.println(text);
        System.out.println(text.getClass());
    }
}
